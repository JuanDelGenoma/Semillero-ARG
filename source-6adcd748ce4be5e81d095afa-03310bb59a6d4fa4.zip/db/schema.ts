import { integer, jsonb, pgTable, serial, text, timestamp, uniqueIndex } from 'drizzle-orm/pg-core'

/** One saved career per user and slot. `state` is the whole GameState as JSON. */
export const careers = pgTable(
  'careers',
  {
    id: serial().primaryKey(),
    userId: text('user_id').notNull(),
    slot: integer().notNull(),
    clubId: text('club_id').notNull(),
    managerName: text('manager_name').notNull(),
    season: integer().notNull(),
    week: integer().notNull(),
    state: jsonb().notNull(),
    updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex('careers_user_slot').on(t.userId, t.slot)],
)
