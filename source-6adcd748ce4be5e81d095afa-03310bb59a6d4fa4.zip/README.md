# Semillero — Simulador de Inferiores

Un juego de gestión de divisiones juveniles basado en el sistema argentino. Elegís uno de los 30 clubes reales de la Liga Profesional y coordinás sus seis categorías, de novena (Sub 14) a cuarta (Sub 20): armás el equipo titular de cada una, jugás la Liga AFA semana a semana, lidiás con lesiones y suspensiones, y al final de cada año despedís a los que suben a Reserva y recibís a la camada nueva.

## Qué se puede hacer hoy

- **Nueva carrera**: elegir club y nombre del coordinador.
- **Oficina**: próxima fecha por categoría, últimos resultados con goleadores, novedades, enfermería y sanciones.
- **Plantel**: jugadores de cada categoría con nivel, potencial, estadísticas, tarjetas y estado. Ficha de jugador con opción de registrarlo en una categoría mayor.
- **Alineación**: cancha 4-3-3 interactiva por categoría; jugadores de categorías menores pueden jugar arriba, nunca al revés.
- **Partidos**: fixture del club con detalle de cada partido (goles, asistencias, tarjetas, lesiones) y la fecha completa.
- **Tablas**: posiciones y goleadores de la Liga AFA por categoría.
- **Cierre de temporada**: campeones, ascensos a Reserva y llegada de la nueva camada.

## Tecnología

- [TanStack Start](https://tanstack.com/start) + React 19 + TypeScript
- Tailwind CSS 4 y componentes shadcn/ui
- Motor de simulación propio en `src/game` (TypeScript puro, PRNG con semilla)
- Netlify (hosting, Image CDN para la imagen de portada)

## Correr localmente

```bash
pnpm install
netlify dev   # o: pnpm dev
```

## Lo que falta

La carrera hoy vive en memoria (se pierde al recargar). La hoja de ruta completa está en [PLAN.md](PLAN.md): guardado de partidas con cuentas, Liga Metro y ciudadanía de extranjeros, descartes de fin de año, selecciones juveniles (Liga Evolución, Sudamericano y Mundiales), Messi Cup, captación, ofertas de Europa y eventos aleatorios.
