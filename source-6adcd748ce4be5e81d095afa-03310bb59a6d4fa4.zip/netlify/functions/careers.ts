import type { Config, Context } from '@netlify/functions'
import { AuthError, getUser, verifyRequestOrigin } from '@netlify/identity'
import { and, asc, eq } from 'drizzle-orm'
import { db } from '../../db/index.js'
import { careers } from '../../db/schema.js'

const SLOTS = 3
/** Compressed upload limit; a long career is a few hundred KB gzipped. */
const MAX_BYTES = 5 * 1024 * 1024

const json = (body: unknown, status = 200) => Response.json(body, { status })
const error = (message: string, status: number) => json({ error: message }, status)

/** Careers arrive gzipped from the browser to stay well under the request size limit. */
async function readState(req: Request) {
  const raw = await req.arrayBuffer()
  if (raw.byteLength > MAX_BYTES) return null
  const text = await new Response(new Blob([raw]).stream().pipeThrough(new DecompressionStream('gzip'))).text()
  return JSON.parse(text) as Record<string, unknown>
}

export default async (req: Request, context: Context) => {
  const user = await getUser()
  if (!user) return error('Tenés que iniciar sesión para guardar carreras.', 401)

  const slotParam = context.params.slot
  if (!slotParam) {
    if (req.method !== 'GET') return error('Método no permitido', 405)
    const rows = await db
      .select({
        slot: careers.slot,
        clubId: careers.clubId,
        managerName: careers.managerName,
        season: careers.season,
        week: careers.week,
        updatedAt: careers.updatedAt,
      })
      .from(careers)
      .where(eq(careers.userId, user.id))
      .orderBy(asc(careers.slot))
    return json(rows)
  }

  const slot = Number(slotParam)
  if (!Number.isInteger(slot) || slot < 1 || slot > SLOTS) return error('Ranura inválida', 400)
  const mine = and(eq(careers.userId, user.id), eq(careers.slot, slot))

  if (req.method === 'GET') {
    const [row] = await db.select({ state: careers.state }).from(careers).where(mine)
    if (!row) return error('No hay ninguna carrera en esa ranura.', 404)
    return json(row.state)
  }

  // Saving and deleting rely on the session cookie, so only accept same-origin requests.
  try {
    verifyRequestOrigin(req)
  } catch (e) {
    if (e instanceof AuthError) return error('Origen no permitido', 403)
    throw e
  }

  if (req.method === 'PUT') {
    let state: Record<string, unknown> | null
    try {
      state = await readState(req)
    } catch {
      return error('La partida enviada está dañada.', 400)
    }
    if (!state) return error('La partida es demasiado grande.', 413)
    const { clubId, managerName, season, week } = state
    if (typeof clubId !== 'string' || typeof season !== 'number' || typeof week !== 'number' || !Array.isArray(state.players))
      return error('La partida enviada no es válida.', 400)
    const meta = {
      clubId,
      managerName: typeof managerName === 'string' ? managerName.slice(0, 60) : '',
      season,
      week,
      state,
      updatedAt: new Date(),
    }
    const [saved] = await db
      .insert(careers)
      .values({ userId: user.id, slot, ...meta })
      .onConflictDoUpdate({ target: [careers.userId, careers.slot], set: meta })
      .returning({ slot: careers.slot, updatedAt: careers.updatedAt })
    return json(saved)
  }

  if (req.method === 'DELETE') {
    await db.delete(careers).where(mine)
    return new Response(null, { status: 204 })
  }

  return error('Método no permitido', 405)
}

export const config: Config = {
  path: ['/api/careers', '/api/careers/:slot'],
}
