# Semillero — hoja de ruta

Semillero es un simulador de inferiores del fútbol argentino. Se construye por etapas: primero el corazón jugable (planteles, alineaciones y la Liga AFA), después cada sistema que le da profundidad a la carrera.

## Hito 1 — Núcleo jugable ✅

- Portada, selección entre los 30 clubes reales de la Liga Profesional y nombre del coordinador.
- Seis categorías (novena a cuarta) con plantel generado según la cantera del club.
- Elegibilidad por año de nacimiento al inicio de la temporada; registrar jugadores en categorías mayores; un jugador nunca baja de categoría.
- Alineación 4-3-3 por categoría, con penalización por jugar fuera de posición y relleno automático de huecos.
- Liga AFA (todos contra todos, 29 fechas) en las seis categorías, con resultados, goleadores, asistencias y tarjetas.
- Lesiones con tiempos de baja, expulsiones con fechas de suspensión y acumulación de 5 amarillas.
- Evolución semanal de los jugadores según edad, potencial y minutos.
- Cierre de temporada: campeones, pase a Reserva (por edad o por ser un crack precoz) y llegada de la camada nueva a novena.

## Hito 2 — Guardar la carrera

- Cuentas de usuario con Netlify Identity.
- Guardado y carga de carreras en Netlify Database (estado de partida serializado + metadatos: club, temporada, fecha).
- Varias ranuras de guardado por usuario y autoguardado al avanzar de semana.

## Hito 3 — Liga Metro y jugadores extranjeros

- Torneo secundario Liga Metropolitana para 7ª, 8ª y 9ª, jugado la misma semana por los que no sumaron minutos en AFA.
- Nacionalidad y residencia: un extranjero fichado necesita dos años en el país para la ciudadanía; sin ciudadanía sólo juega Liga Metro.

## Hito 4 — Fin de año completo

- Pedido de la coordinación para descartar jugadores (cupos por categoría) antes de cerrar la temporada.
- Mejor criterio de ascenso precoz a Reserva (16/17 años) con aviso de la Primera.
- Historial de temporadas y palmarés del club.

## Hito 5 — Selecciones juveniles

- Convocatorias mensuales Sub 15 y Sub 17: los convocados no están disponibles para el club.
- CONMEBOL Liga Evolución (Sub 15, 5 días por convocatoria), entrenamientos de 3 días cuando no hay torneo.
- Sudamericano Sub 17 (25 días) y Mundiales Sub 15 y Sub 17 (hasta 25 días, menos si la selección queda afuera), con 90 % de clasificación.
- Tras un Mundial: 10 % de chance de subir a Reserva, 50 % si la selección llega a semifinales.
- Jugadores de otras nacionalidades convocados por su país (sudamericanos: mismos torneos; resto: sólo se nombra el Mundial).

## Hito 6 — Messi Cup

- Torneo anual Sub 16 en el exterior: grupos de 4, semifinal y final contra academias europeas y clubes ligados a Messi.
- Plantel de ~20 viajeros elegidos de cualquier categoría elegible, ausentes del club durante el torneo.

## Hito 7 — Captación, mercado y eventos

- Sistema de captación (ojeadores, pruebas, fichajes de chicos de otras academias o del interior).
- Candidatos de todo el mundo para River y Boca; probabilidad mínima para el resto.
- Ofertas de clubes grandes de Europa por tus juveniles, con decisión del coordinador.
- Eventos aleatorios: una figura de otra academia se ofrece, una familia se muda, un chico de la pensión con problemas de conducta, etc.

## Hito 8 — Pulido

- Reportes de partido más ricos, estadísticas históricas por jugador, filtros y orden en el plantel.
- Ajuste fino del balance (nivel de rivales, crecimiento, lesiones).
